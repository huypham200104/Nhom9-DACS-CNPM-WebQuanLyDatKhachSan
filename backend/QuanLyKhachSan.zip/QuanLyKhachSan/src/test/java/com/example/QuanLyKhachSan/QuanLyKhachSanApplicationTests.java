package com.example.QuanLyKhachSan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuanLyKhachSanApplicationTests {

	@Test
	void contextLoads() {
	}

}
