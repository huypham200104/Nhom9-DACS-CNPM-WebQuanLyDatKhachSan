package com.example.QuanLyKhachSan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuanLyKhachSanApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuanLyKhachSanApplication.class, args);
	}

}
